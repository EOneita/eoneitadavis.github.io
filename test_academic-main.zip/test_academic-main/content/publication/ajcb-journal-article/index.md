---
abstract: An editorial emphasizing that consumer research is necessary now, more than ever.
authors:
- admin
- Megan A. Owen
- Jenny Anne Glikman
date: "2021-03-01T00:00:00Z"
doi: ""
featured: false
image:
  caption: ''
  focal_point: ""
  preview_only: false
projects: []
publication: '*Asian Journal of Conservation Biology, 10*(1), 1-2'
publication_short: ""
publication_types:
- "2"
publishDate: "2021-03-01T00:00:00Z"
slides: none
summary: Etc
tags:
- Source Themes
title: Wildlife Trade in 2021, Still start with the consumer
url_code: ""
url_dataset: ""
url_pdf: https://www.ajcb.in/journals/full_papers_july_2021/Editorial_AJCB-Vol10-No1-Davis%20et%20al.pdf
url_poster: ""
url_project: ""
url_slides: ""
url_source: ""
url_video: ""
---
